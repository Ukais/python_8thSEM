# This function takes in a list of stock prices and returns the best buying and selling days to maximize profit
def Best_Buying_Selling_Day(stock_prices):
    n = len(stock_prices) # get the number of days of stock prices
    maximum_profit = 0 # initialize the maximum profit to 0
    buying_day = 0 # initialize the buying day to the first day
    selling_day = 0 # initialize the selling day to the first day

    # loop through each day in the stock prices list
    for i in range(n):
        # loop through each day after the current buying day
        for j in range(i + 1, n):
            profit = stock_prices[j] - stock_prices[i] # calculate the profit by subtracting the buying price from the selling price
            # if the calculated profit is greater than the current maximum profit
            if profit > maximum_profit:
                # update the maximum profit, buying day, and selling day
                maximum_profit = profit
                buying_day = i
                selling_day = j

    # return the buying day and selling day as a tuple
    return buying_day, selling_day

# create an example list of stock prices
stock_prices = [100, 180, 260, 310, 40, 535, 695]
# call the Best_Buying_Selling_Day function with the example list of stock prices
best_days = Best_Buying_Selling_Day(stock_prices)
# print the best buying and selling days and prices using string formatting
print("Buy stock on: day", best_days[0] + 1, "(price=", stock_prices[best_days[0]], ")")
print("Sell stock on: day", best_days[1] + 1, "(price=", stock_prices[best_days[1]], ")")
