from typing import List, Optional

# This function takes in a list of book titles and their publication years and returns the earliest year in which a trilogy was published
def earliest_trilogy_year(titles: List[str], years: List[int]) -> Optional[int]:
    books = {} # initialize an empty dictionary to store books by year
    for title, year in zip(titles, years): # iterate over the title and year lists simultaneously
        if year in books: # if the year is already in the dictionary
            books[year].append(title) # add the title to the list of books for that year
        else: # otherwise
            books[year] = [title] # create a new key-value pair for the year and list containing the title

    for year in sorted(books.keys()): # iterate over the years in the dictionary, sorted in ascending order
        if year + 1 in books and year + 2 in books: # if the subsequent two years have books in the dictionary
            return year # return the current year as the earliest year in which a trilogy was published
    return None # if no trilogy is found, return None

# create example lists of book titles and publication years
titles = ['The Hunger Games', 'Catching Fire', 'Mockingjay', 'The Lord of the Rings', 'The Two Towers', 'The Return of the King', 'Divergent', 'Insurgent', 'Allegiant']
years = [2008, 2009, 2010, 1954, 1955, 1956, 2011, 2012, 2013]

# call the earliest_trilogy_year function with the example lists and print the result
print(earliest_trilogy_year(titles, years))
