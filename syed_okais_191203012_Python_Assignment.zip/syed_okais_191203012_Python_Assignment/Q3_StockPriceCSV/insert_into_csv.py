#import csv module
import csv
#open csv file in write mode
with open('stock_prices.csv', 'w', newline='') as csvfile:
    #create object of writer
    writer = csv.writer(csvfile)
     #write the row data
    writer.writerow(['Symbol', 'Date', 'Price'])

    writer.writerow(['AAPL', '2022-01-01', 135.90])
    writer.writerow(['AAPL', '2022-01-02', 138.45])
    writer.writerow(['AAPL', '2022-01-03', 142.20])
    writer.writerow(['GOOG', '2022-01-01', 2105.75])
    writer.writerow(['GOOG', '2022-01-02', 2098.00])
    writer.writerow(['GOOG', '2022-01-03', 2125.50])
    writer.writerow(['MSFT', '2022-01-01', 345.20])
    writer.writerow(['MSFT', '2022-01-02', 344.70])
    writer.writerow(['MSFT', '2022-01-03', 342.10])
