# import the csv module to read the csv file
import csv

# create an empty dictionary to store stock prices
stock_prices = {}

# open the csv file in read mode using a context manager
with open('stock_prices.csv', 'r') as csvfile:

    # create a csv reader object
    reader = csv.DictReader(csvfile)

    # loop through each row of the csv file
    for row in reader:

        # get the symbol, date, and price from the current row
        symbol = row['Symbol']
        date = row['Date']
        price = float(row['Price'])

        # check if the current symbol is already in the dictionary
        if symbol in stock_prices:

            # if the price is higher than the highest price seen so far for the symbol, update the highest price
            if price > stock_prices[symbol]['highest']:
                stock_prices[symbol]['highest'] = price

            # if the price is lower than the lowest price seen so far for the symbol, update the lowest price
            elif price < stock_prices[symbol]['lowest']:
                stock_prices[symbol]['lowest'] = price

        # if the current symbol is not in the dictionary, add it with the current price as both the highest and lowest price
        else:
            stock_prices[symbol] = {'highest': price, 'lowest': price}

# loop through each symbol in the dictionary and print the highest and lowest prices
for symbol in stock_prices:
    print('stock symbol:', symbol)
    print('Highest price:', stock_prices[symbol]['highest'])
    print('Lowest price:', stock_prices[symbol]['lowest'])
    print()
