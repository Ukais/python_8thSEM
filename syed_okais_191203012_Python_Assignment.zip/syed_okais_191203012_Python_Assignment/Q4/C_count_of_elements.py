#Initialize a list
list = [11, 45, 8, 11, 23, 45, 23, 45, 89, 11, 89]

#Create a dictionary to store count of each element in the list
count = {}

#Loop through the elements in the list
for element in list:
    # Check if the element is already in the dictionary If yes, increment the count by 1
    if element in count:
        count[element] += 1
        #If no, add the element to the dictionary with a count of 1
    else:
        count[element] = 1
#Print the count of each element in the dictionary
print("Printing count of each item", count)
