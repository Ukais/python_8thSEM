# Define a function that shifts a list one position to the left
def shift_left(lst):
    return lst[1:] + [lst[0]]

# Call the shift_left function with two different input lists
print('original list:', 1, 2, 3)
print('new list is:', shift_left([1, 2, 3]))
print()

print('original list:', 11, 12, 13)
print('new list is:', shift_left([11, 12, 13]))
