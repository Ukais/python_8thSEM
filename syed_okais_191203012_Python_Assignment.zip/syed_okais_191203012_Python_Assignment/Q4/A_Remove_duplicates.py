list_of_lists = [[10, 20], [40], [30, 56, 25], [10, 20], [33], [40]]

unique_list_of_lists = []

# iterate over each list in the original list
for lst in list_of_lists:
    # check if the list is already in the unique list
    if lst not in unique_list_of_lists:
        # if it's not, add it to the unique list
        unique_list_of_lists.append(lst)

# print the unique list of lists
print(unique_list_of_lists)
